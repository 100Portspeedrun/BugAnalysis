=== FXCM SCRAPER DIAGNOSTICS PACKAGE ===

This package contains diagnostic files captured when the FXCM scraper fails.

Files:
  • *.png - Screenshots captured before page closes
  • fxcm_console_*.txt - Browser console messages (errors, warnings)
  • fxcm_network_*.txt - Network errors (403, 429, etc.)
  • fxcm_html_*.html - HTML snapshot of the page before it closed
  • *.webm - Video recording of the entire browser session

These are all standard file formats that Windows can open directly.

If no files are present yet, run the scraper once to generate them.
